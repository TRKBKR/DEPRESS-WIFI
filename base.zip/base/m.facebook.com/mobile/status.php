<?php
headers('location= "/index.php"');
?>
